package com.academy.class10choose;

public class Aluno {
    String nome;
    int idade, ra;
    
    void Login(){
        
    }
    
    void AcessarQuadroAulas(){
        
    }
    
    void AcessarBoletim(){
        
    }
}
