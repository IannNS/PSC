package com.academy.class10choose;

public class Paciente {
    String nome, endereco, quadro;
    
    void RealizarConsulta(){
        
    }
    
    void AcompanharConsulta(){
        
    }
    
    void SolicitarResultadoConsulta(){
        
    }
}
