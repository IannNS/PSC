package com.academy.class10choose;

public class ContaBancaria {
    String titular;
    int agencia, conta;
    
    void SacarValor(){
        
    }
    
    void DepositarValor(){
        
    }
    
    void SolicitarEmprestimo(){
        
    }
}
