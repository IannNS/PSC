/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.academy.class10choose;

/**
 *
 * @author ianns
 */
public class Class10Choose {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
